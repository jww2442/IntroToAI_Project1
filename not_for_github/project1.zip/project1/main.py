import Item
import NearestNeighbor
import file_io

def main():
    N = 5
    k = 5
    fileSize = 1000

    nGroups = file_io.init_groups(fileSize, N)

    storeAllAccuracies = {}

    for i in range(N):

        testGroup = nGroups[i]
        testItems = []
        for j in range(len(testGroup)):
            testItems.append(Item.Item(testGroup[j]))
        
        nn = NearestNeighbor.NearestNeighbor()
        exampleItems = nn.storeAll(nGroups, i, N)

        prediction = nn.predict3(testItems, exampleItems, k)

        storeAllAccuracies.update({i+1: nn.calcAccuracy(prediction, testItems)})
    

    
    print('Accuracies of Store All for Group 1:', storeAllAccuracies.get(1), '\nAccuracies of Store All for Group 2:', storeAllAccuracies.get(2), '\nAccuracies of Store All for Group 3:', storeAllAccuracies.get(3), '\nAccuracies of Store All for Group 4:', storeAllAccuracies.get(4), '\nAccuracies of Store All for Group 5:', storeAllAccuracies.get(5), '\nAverage accuracy of Store All:', (storeAllAccuracies.get(1) + storeAllAccuracies.get(2) + storeAllAccuracies.get(3) + storeAllAccuracies.get(4) + storeAllAccuracies.get(5))/5, '\n\n')
  
    

main()


N = 5
k = 5
fileSize = 1000

errAccuracies = {}

for i in range(N):


    nGroups = file_io.init_groups(fileSize, N)

    nn = NearestNeighbor.NearestNeighbor()

    exampleErrors = nn.storeErrors(nGroups, i, k, N)

    testGroup = nGroups[i]
    testItems = []
    for j in range(len(testGroup)):
        testItems.append(Item.Item(testGroup[j]))

    
    prediction2 = nn.predict3(testItems, exampleErrors, k)

    acc = nn.calcAccuracy(prediction2, testItems)

    errAccuracies.update({i: acc})

print('Accuracies of Store Errors for Group 1:', errAccuracies.get(0), '\nAccuracies of Store Errors for Group 2:', errAccuracies.get(1), '\nAccuracies of Store Errors for Group 3:', errAccuracies.get(2), '\nAccuracies of Store Errors for Group 4:', errAccuracies.get(3), '\nAccuracies of Store Errors for Group 5:', errAccuracies.get(4), '\nAverage accuracy of Store Errors:', (errAccuracies.get(1) + errAccuracies.get(2) + errAccuracies.get(3) + errAccuracies.get(4) + errAccuracies.get(0))/5, '\n\n')

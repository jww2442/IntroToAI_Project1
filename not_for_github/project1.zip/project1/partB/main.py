from ga_util import bitstr2float
from organism import createInitialPopulation
import genetic_algorithm

def main():

    functionNames = ['sphere', 'shekel', 'langermann', 'bump']

    populationSize = 1000
    chromosomeCount = 2
    bitStrLength = 52
    population1 = createInitialPopulation(populationSize, chromosomeCount, bitStrLength)

    numParents = 2
    mutationChance = 0.001
    numGenerations = 500

    for funcTest in functionNames:
        
        final = genetic_algorithm.geneticAlgorithm(population1, numParents, mutationChance, numGenerations, funcTest)

        print('Function:', funcTest, '\n\tNumber of iterations of Genetic Algorithm:', numGenerations, '\n\tFittest bit-string pair:', final[0], '\n\tResulting input: [', bitstr2float(final[0][0]), ', ', bitstr2float(final[0][1]), ']\n\tResulting output on', funcTest, 'function:', final[1][1], '\n\n')

main()